OFFLINE BUNDLE v2

Copy the ENTIRE bundle folder to the offline machine.
The offline machine must already have matching Python, pip and venv.

Linux:   ./run.sh --verify
         ./run.sh --entry path/to/main.py
Windows: run.bat --verify
         run.bat --entry path\to\main.py

Install without running: python install_offline.py --install-only
Repair: python install_offline.py --reinstall --verify

Do not copy a virtual environment across operating systems.
Do not use --preinstall from a different OS.
If the code uses dynamic imports, add their packages with --extra or requirements.txt.
Native OS libraries, external executables and Python itself are not bundled.
For best results build on the same OS/version as target and test on a clean VM.
