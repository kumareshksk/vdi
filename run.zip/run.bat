@echo off
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 install_offline.py %*
) else (
  python install_offline.py %*
)
