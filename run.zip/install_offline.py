#!/usr/bin/env python3
"""Offline install and run. Requires Python 3.9+, pip, and venv."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
MANIFEST = json.loads((ROOT / 'manifest.json').read_text(encoding='utf-8'))
VENV = ROOT / '.offline_venv'
PY = VENV / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')

def check_target():
    expected = MANIFEST['target']
    actual_os = 'windows' if os.name == 'nt' else ('linux' if sys.platform.startswith('linux') else sys.platform)
    if actual_os != expected['os']:
        raise RuntimeError('OS mismatch: bundle is for %s, running on %s' % (expected['os'], actual_os))
    version = '%d.%d' % sys.version_info[:2]
    if version != expected['python']:
        raise RuntimeError('Python mismatch: bundle requires %s, found %s' % (expected['python'], version))
    import platform
    actual_arch = platform.machine().lower()
    normalized = {'amd64':'x86_64','x64':'x86_64','arm64':'aarch64'}.get(actual_arch, actual_arch)
    if normalized != expected['arch']:
        raise RuntimeError('Architecture mismatch: bundle requires %s, found %s' % (expected['arch'], normalized))

def install(force=False):
    check_target()
    marker = VENV / '.bundle_complete'
    if force or not marker.exists() or not PY.exists():
        if VENV.exists():
            import shutil
            shutil.rmtree(VENV)
        subprocess.run([sys.executable, '-m', 'venv', str(VENV)], check=True)
        subprocess.run([str(PY), '-m', 'pip', 'install', '--isolated', '--no-index',
                        '--find-links', str(ROOT / 'wheels'), '--no-cache-dir',
                        '--requirement', str(ROOT / 'requirements.txt')], check=True)
        subprocess.run([str(PY), '-m', 'pip', 'check'], check=True)
        marker.write_text('ok\n', encoding='utf-8')
    return PY

def verify():
    install()
    code = """import importlib, json, sys
mods=json.loads(sys.argv[1]); failures=[]
for mod in mods:
 try:
  importlib.import_module(mod)
  print('OK', mod)
 except Exception as e:
  failures.append((mod,str(e))); print('FAIL',mod,repr(e))
if failures: sys.exit(1)
"""
    subprocess.run([str(PY), '-c', code, json.dumps(MANIFEST['verify_imports'])],
                   cwd=str(ROOT / MANIFEST['project_dir']), check=True)
    print('Verified %d import(s)' % len(MANIFEST['verify_imports']))

def main():
    p = argparse.ArgumentParser(description='Offline install, verify, or run project')
    p.add_argument('--install-only', action='store_true')
    p.add_argument('--verify', action='store_true')
    p.add_argument('--reinstall', action='store_true')
    p.add_argument('--entry', help='Relative path of entry point inside project')
    args, extra = p.parse_known_args()
    try:
        install(args.reinstall)
        if args.verify:
            verify()
        if args.install_only or args.verify:
            return
        entry = args.entry or MANIFEST.get('entry')
        if not entry:
            p.error('Specify --entry relative/path/to/script.py')
        project = (ROOT / MANIFEST['project_dir']).resolve()
        script = (project / entry).resolve()
        if not script.is_relative_to(project) or not script.is_file():
            p.error('Invalid entry: %s' % entry)
        if extra and extra[0] == '--': extra = extra[1:]
        subprocess.run([str(PY), str(script)] + extra, cwd=str(project), check=True)
    except (RuntimeError, subprocess.CalledProcessError) as e:
        print('ERROR:', e, file=sys.stderr)
        sys.exit(1)
if __name__ == '__main__': main()
