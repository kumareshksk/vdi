#!/usr/bin/env python3
"""Build a reproducible offline Python wheelhouse and project launcher.

Requires Python >=3.9 and pip on the connected build host. The target must
already have compatible Python, pip and venv. Does not bundle Python itself.
"""
import argparse
import ast
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import sysconfig
import tempfile

ALIASES = {'PIL':'Pillow','cv2':'opencv-python','yaml':'PyYAML','bs4':'beautifulsoup4',
           'sklearn':'scikit-learn','dateutil':'python-dateutil','dotenv':'python-dotenv',
           'jwt':'PyJWT','Crypto':'pycryptodome','Cryptodome':'pycryptodomex',
           'serial':'pyserial','docx':'python-docx','pptx':'python-pptx',
           'dissect':'dissect.cstruct','elftools':'pyelftools','pwn':'pwntools',
           'nacl':'PyNaCl','OpenSSL':'pyOpenSSL','ldap':'python-ldap',
           'dns':'dnspython','pwnlib':'pwntools','future':'future',
           'impacket':'impacket','ldap3':'ldap3','frozendict':'frozendict',
           'requests':'requests','dissect':'dissect.cstruct'}
EXCLUDE = {'.git','.hg','.svn','.venv','venv','env','__pycache__','node_modules',
           'offline_bundle','wheels','libs','.tox','.mypy_cache','.pytest_cache'}

INSTALLER = r'''#!/usr/bin/env python3
"""Offline install and run. Requires Python 3.9+, pip, and venv."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
MANIFEST = json.loads((ROOT / 'manifest.json').read_text(encoding='utf-8'))
VENV = ROOT / '.offline_venv'
PY = VENV / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')

def check_target():
    expected = MANIFEST['target']
    actual_os = 'windows' if os.name == 'nt' else ('linux' if sys.platform.startswith('linux') else sys.platform)
    if actual_os != expected['os']:
        raise RuntimeError('OS mismatch: bundle is for %s, running on %s' % (expected['os'], actual_os))
    version = '%d.%d' % sys.version_info[:2]
    if version != expected['python']:
        raise RuntimeError('Python mismatch: bundle requires %s, found %s' % (expected['python'], version))
    import platform
    actual_arch = platform.machine().lower()
    normalized = {'amd64':'x86_64','x64':'x86_64','arm64':'aarch64'}.get(actual_arch, actual_arch)
    if normalized != expected['arch']:
        raise RuntimeError('Architecture mismatch: bundle requires %s, found %s' % (expected['arch'], normalized))

def install(force=False):
    check_target()
    marker = VENV / '.bundle_complete'
    if force or not marker.exists() or not PY.exists():
        if VENV.exists():
            import shutil
            shutil.rmtree(VENV)
        subprocess.run([sys.executable, '-m', 'venv', str(VENV)], check=True)
        subprocess.run([str(PY), '-m', 'pip', 'install', '--isolated', '--no-index',
                        '--find-links', str(ROOT / 'wheels'), '--no-cache-dir',
                        '--requirement', str(ROOT / 'requirements.txt')], check=True)
        subprocess.run([str(PY), '-m', 'pip', 'check'], check=True)
        marker.write_text('ok\n', encoding='utf-8')
    return PY

def verify():
    install()
    code = """import importlib, json, sys
mods=json.loads(sys.argv[1]); failures=[]
for mod in mods:
 try:
  importlib.import_module(mod)
  print('OK', mod)
 except Exception as e:
  failures.append((mod,str(e))); print('FAIL',mod,repr(e))
if failures: sys.exit(1)
"""
    subprocess.run([str(PY), '-c', code, json.dumps(MANIFEST['verify_imports'])],
                   cwd=str(ROOT / MANIFEST['project_dir']), check=True)
    print('Verified %d import(s)' % len(MANIFEST['verify_imports']))

def main():
    p = argparse.ArgumentParser(description='Offline install, verify, or run project')
    p.add_argument('--install-only', action='store_true')
    p.add_argument('--verify', action='store_true')
    p.add_argument('--reinstall', action='store_true')
    p.add_argument('--entry', help='Relative path of entry point inside project')
    args, extra = p.parse_known_args()
    try:
        install(args.reinstall)
        if args.verify:
            verify()
        if args.install_only or args.verify:
            return
        entry = args.entry or MANIFEST.get('entry')
        if not entry:
            p.error('Specify --entry relative/path/to/script.py')
        project = (ROOT / MANIFEST['project_dir']).resolve()
        script = (project / entry).resolve()
        if not script.is_relative_to(project) or not script.is_file():
            p.error('Invalid entry: %s' % entry)
        if extra and extra[0] == '--': extra = extra[1:]
        subprocess.run([str(PY), str(script)] + extra, cwd=str(project), check=True)
    except (RuntimeError, subprocess.CalledProcessError) as e:
        print('ERROR:', e, file=sys.stderr)
        sys.exit(1)
if __name__ == '__main__': main()
'''

RUN_SH = '''#!/bin/sh
set -eu
cd "$(dirname "$0")"
exec python3 install_offline.py "$@"
'''
RUN_BAT = '''@echo off
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  py -3 install_offline.py %*
) else (
  python install_offline.py %*
)
'''

def python_files(root):
    return sorted(p for p in root.rglob('*.py') if p.name not in {'prepare_offline.py','prepare_offline_v2.py'} and not any(x in EXCLUDE for x in p.relative_to(root).parts))

def scan(root):
    files = python_files(root)
    local = {p.stem for p in files} | {p.name for p in root.iterdir() if p.is_dir()}
    stdlib = getattr(sys, 'stdlib_module_names', set())
    imports = set()
    for p in files:
        try:
            tree = ast.parse(p.read_text(encoding='utf-8-sig'))
        except (SyntaxError, UnicodeError) as e:
            print('WARNING: cannot scan %s: %s' % (p,e), file=sys.stderr)
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                imports.update(a.name.split('.')[0] for a in node.names)
            elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
                imports.add(node.module.split('.')[0])
    imports -= (local | set(stdlib) | {'__future__'})
    distmap = metadata.packages_distributions()
    requirements = set()
    unknown = []
    for name in sorted(imports):
        dist = ALIASES.get(name) or (distmap.get(name) or [None])[0]
        if not dist:
            # Most Python distributions share their import name. Try that
            # automatically; pip will fail loudly if it does not exist.
            dist = name
            unknown.append(name)
        requirements.add(dist)
    return sorted(requirements), sorted(imports), unknown

def copy_project(source, dest):
    shutil.copytree(source, dest, ignore=shutil.ignore_patterns(*EXCLUDE,'*.pyc','*.pyo'), dirs_exist_ok=True)

def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('project', type=Path, help='Python project directory or single .py file')
    parser.add_argument('--requirements', type=Path, help='Explicit pip requirements file (recommended)')
    parser.add_argument('--extra', action='append', default=[], help='Additional distribution requirement; repeatable')
    parser.add_argument('--entry', help='Entry script relative to project root')
    parser.add_argument('--output', type=Path, default=Path('offline_bundle'))
    parser.add_argument('--os', choices=['linux','windows'], required=True)
    parser.add_argument('--arch', choices=['x86_64','aarch64'], required=True)
    parser.add_argument('--python-version', required=True, help='Target major.minor, e.g. 3.11')
    parser.add_argument('--platform-tag', help='Override pip wheel platform tag')
    parser.add_argument('--scan-only', action='store_true')
    args = parser.parse_args()
    source = args.project.resolve()
    if not source.exists(): parser.error('Project does not exist')
    if not args.python_version.count('.') == 1 or not all(s.isdigit() for s in args.python_version.split('.')):
        parser.error('Use --python-version MAJOR.MINOR')
    if args.os == 'windows' and args.arch == 'aarch64':
        default_tag = 'win_arm64'
    else:
        default_tag = {('windows','x86_64'):'win_amd64',
                       ('linux','x86_64'):'manylinux2014_x86_64',
                       ('linux','aarch64'):'manylinux2014_aarch64'}[(args.os,args.arch)]
    tag = args.platform_tag or default_tag
    root = source.parent if source.is_file() else source
    auto_reqs, imports, unknown = scan(root)
    print('Detected imports:', ', '.join(imports) or '(none)')
    if unknown:
        print('UNRESOLVED IMPORTS:', ', '.join(unknown), file=sys.stderr)
        print('Attempting same-name distributions automatically; pip will validate.', file=sys.stderr)
    if args.scan_only: return
    # Unknown names are attempted automatically; no manual package entry required.
    output = args.output.resolve()
    if output == root or root in output.parents and output.name != 'offline_bundle':
        parser.error('Output must be outside the project, or named offline_bundle')
    if output.exists(): shutil.rmtree(output)
    output.mkdir(parents=True)
    dest = output / 'project'
    if source.is_file():
        dest.mkdir()
        shutil.copy2(source, dest / source.name)
        entry = args.entry or source.name
    else:
        copy_project(source, dest)
        entry = args.entry
        if not entry:
            top = [p.relative_to(root).as_posix() for p in python_files(root) if p.parent == root]
            if len(top) == 1: entry = top[0]
    req = output / 'requirements.txt'
    if args.requirements:
        # Preserve full pip requirement syntax, including extras/markers/constraints.
        # For safety, reject local references and pip options that cannot be replayed offline.
        content = args.requirements.read_text(encoding='utf-8')
        for line in content.splitlines():
            s = line.strip()
            if s and not s.startswith('#') and (s.startswith('-') or ' @ ' in s or s.startswith(('.', '/', 'git+'))):
                parser.error('Unsupported requirements directive/local reference: %s' % s)
        lines = [content.rstrip()] + auto_reqs
    else:
        lines = auto_reqs[:]
    lines += args.extra
    req.write_text('\n'.join(lines).strip() + '\n', encoding='utf-8')
    wheels = output / 'wheels'
    wheels.mkdir()
    command = [sys.executable,'-m','pip','download','--isolated','--disable-pip-version-check',
               '--dest',str(wheels),'--only-binary=:all:',
               '--platform',tag,'--python-version',args.python_version,
               '--implementation','cp','--abi','cp'+args.python_version.replace('.',''),
               '--abi','abi3','--abi','none','--requirement',str(req)]
    print('Downloading for:',args.os,args.arch,'Python',args.python_version,'tag',tag,flush=True)
    try:
        subprocess.run(command,check=True)
    except subprocess.CalledProcessError:
        print('FAILED: missing/incompatible wheel or dependency resolution error. Bundle is NOT ready.',file=sys.stderr)
        raise SystemExit(1)
    # Offline resolver dry-run on the build host, using the target tags, validates completeness.
    # pip download already resolves transitive dependencies and fails if unavailable.
    manifest = {'target':{'os':args.os,'arch':args.arch,'python':args.python_version,'platform_tag':tag},
                'project_dir':'project','entry':entry,'verify_imports':imports,
                'unresolved_imports':unknown,'requirements':req.read_text(encoding='utf-8').splitlines()}
    (output/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    (output/'install_offline.py').write_text(INSTALLER,encoding='utf-8')
    (output/'run.sh').write_text(RUN_SH,encoding='utf-8')
    (output/'run.sh').chmod(0o755)
    (output/'run.bat').write_text(RUN_BAT,encoding='utf-8')
    (output/'README.txt').write_text('''OFFLINE BUNDLE v2\n\nCopy the ENTIRE bundle folder to the offline machine.\nThe offline machine must already have matching Python, pip and venv.\n\nLinux:   ./run.sh --verify\n         ./run.sh --entry path/to/main.py\nWindows: run.bat --verify\n         run.bat --entry path\\to\\main.py\n\nInstall without running: python install_offline.py --install-only\nRepair: python install_offline.py --reinstall --verify\n\nDo not copy a virtual environment across operating systems.\nDo not use --preinstall from a different OS.\nIf the code uses dynamic imports, add their packages with --extra or requirements.txt.\nNative OS libraries, external executables and Python itself are not bundled.\nFor best results build on the same OS/version as target and test on a clean VM.\n''',encoding='utf-8')
    print('READY:',output,'(%d wheels)'%len(list(wheels.glob('*.whl'))))
    if unknown: print('NOTE: same-name package guesses:',', '.join(unknown))

if __name__ == '__main__': main()
